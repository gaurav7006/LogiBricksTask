import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  //Hospital_url = "http://localhost:3000/Hospital";
  //City_url = "http://localhost:3000/City"
  Patient_url ="http://localhost:8000/api/"
  constructor(private _http:HttpClient) { }
   getHospitalList(){
     return this._http.get("assets/Data.json");
   }

 getCity(){
     return this._http.get("assets/Data.json");
   }

  submitDetails(data){
    return this._http.post(this.Patient_url+"patient/",data)
  }

  getPatientDetails(){
    return this._http.get(this.Patient_url+"patient/")
  }

  deleteRecord(id){
    return this._http.delete(this.Patient_url+"manage-patient/"+id)
  }

  updateRecord(id,data){
    return this._http.put(this.Patient_url+"manage-patient/"+id,data)
  }
}
