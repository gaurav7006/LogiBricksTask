import { Component } from '@angular/core';
import { JitCompiler } from '@angular/compiler'
import { SharedService } from 'src/app/shared.service';
import * as $ from 'jquery';
import { formatCurrency } from '@angular/common';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private sharedservice:SharedService) { }

  title = 'LogiBrikcsTask';
  HospitalList:any;
  CityList:any;
  FilterHospitalList:any;
  patientList:any;
  record:[];
  isPreloader = false;
  age = 0
  editData = {
    "test_name": "",
      "test_date": "",
      "test_price": "",
      "test_result": "",
      "doctor_remark": "",
  } 
  ngOnInit(){
    this.isPreloader = true;    
     this.sharedservice.getHospitalList().subscribe((result)=>{
       this.HospitalList = result.Hospital;
       console.log(this.HospitalList)
     });

     this.sharedservice.getCity().subscribe((result)=>{
       this.CityList = result.City
       console.log(this.CityList)
     });

    this.getPatientDetail();
    this.isPreloader = false;
  }

  onCitySelect(city){
    this.isPreloader = true;
    this.FilterHospitalList = []
    this.HospitalList.forEach(element => {
      if(element.City_Name == city)
        this.FilterHospitalList.push(element);
    });
    console.log(this.FilterHospitalList)
    this.isPreloader = false;
  }

  ageCal(dob){
    this.age = (new Date()).getFullYear() - dob.split("-")[0]
   // alert(this.age)
  }
  SubmitData(value){
    
    this.isPreloader = true;
   
    //console.log((value.date_of_birth).split("-")[0])
    // this.sharedservice.submitDetails(value).subscribe((result)=>{
    //   console.log(result)
    //   this.getPatientDetail();
    //   this.isPreloader = false;
    // })
    $("#close").click();
    $("#reset").click();
  }

  updateData(value){
    var id = this.editData['id']
    this.patientList.forEach(element => {
      if(id == element.id)
        this.editData = element
    });
    
    console.log(this.editData)
     this.sharedservice.updateRecord(id,this.editData).subscribe((result)=>{
       console.log(result)
       alert("Record updated Successfully !")
       this.getPatientDetail()
     })
    $("#close1").click();
    $("#reset1").click();
  }

  getPatientDetail(){
    this.sharedservice.getPatientDetails().subscribe((result)=>{
      this.patientList = result.data;
      console.log(this.patientList)
    });
    
  }

  onDeleteRecord(id){
    this.sharedservice.deleteRecord(id).subscribe((result)=>{
      alert("Record Deleted Successfully !")
      this.getPatientDetail();
    });
  }

  enableEditing(id){
    this.patientList.forEach(element => {
      if(id == element.id){
        this.editData = element
      }
    });
  
  }
}


