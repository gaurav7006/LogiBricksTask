from django.shortcuts import render
from .models import Patient
from .serializers import PatientSerializer
from .forms import PatientForm
from rest_framework import status
from rest_framework.response import Response
from rest_framework import viewsets
from django.shortcuts import get_object_or_404

# Create your views here.

class PatientAPI(viewsets.ModelViewSet):
    serializer_class = PatientSerializer

    def get_queryset(self):
        return Patient.objects.all()

    def get_object(self, *args, **kwargs):
        return Patient.objects.filter(*args, **kwargs)

    # Get users all medias
    def get(self, request):
        try:
            patient_query = self.get_queryset()
            patient_serializer = self.serializer_class(
                patient_query,  many=True,
                context={'request': request}
            )
            return Response({'data': patient_serializer.data}, status=200)
        except Patient.DoesNotExist:
            return Response({'error': 'Record Not Found!...'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({"error": 'Something went wrong'}, status=status.HTTP_400_BAD_REQUEST)
    
    # Get users all medias
    def getSpecificPatient(self, request, id=None):
        try:
            patient_obj = self.get_object(pk=id)
            print(patient_obj)
            patient_serializer = self.serializer_class(
                patient_obj,many=True,
                context={'request': request}
            )
            return Response({'data': patient_serializer.data}, status=200)
        except Patient.DoesNotExist:
            return Response({'error': 'Record Not Found!...'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({"error": 'Something went wrong'}, status=status.HTTP_400_BAD_REQUEST)

    # Create Patient Details media
    def post(self, request):
        try:
            form = PatientForm(data=request.data)
            if form.is_valid():
                patient_obj = form.save()
                patient_serializer = self.serializer_class(
                    patient_obj,
                    context={'request': request}
                )
                return Response({'data': patient_serializer.data}, status=200)
            return Response({"error": form.errors}, status=401)
        except Patient.DoesNotExist:
            return Response({"error": 'User Record Not Found'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({"error": 'Something went wrong'}, status=status.HTTP_400_BAD_REQUEST)

    # Delete Patient's Details
    def delete(self, request, id=None):
        try:
            patient = get_object_or_404(Patient,pk=id)
            patient.delete()
            return Response({"Success": 'Patient Data Deleted'}, status=200)
        except Patient.DoesNotExist:
            return Response({"error": 'Patient Record Not Found'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({"error": 'Something went wrong!'}, status=status.HTTP_400_BAD_REQUEST)

    # for Update User Object partially
    def put(self, request, id=None):
        print("Put method called")
        try:
            patient = get_object_or_404(Patient,pk=id)
            print(request.data)
            serializer = PatientSerializer(patient, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                print("Data Updated")
                return Response(serializer.data, status=200)
            else:
                print(serializer.errors)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Patient.DoesNotExist:
            print("Patient Id Not found")
            return Response({"error": 'Patient Record Not Found'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print(e)
            return Response({"error": 'Something went wrong!'}, status=500)