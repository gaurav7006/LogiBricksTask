from django.db import models

# Create your models here.
class Patient(models.Model):
    first_name              = models.CharField(max_length=255,blank=True,null=True)
    last_name               = models.CharField(max_length=255,blank=True,null=True)
    hospital_name           = models.CharField(max_length=255,blank=True,null=True)
    city                    = models.CharField(max_length=255,blank=True,null=True)
    age                     = models.IntegerField(blank=True,null=True,default=0)
    date_of_birth           = models.DateField(blank=True,null=True)
    admission_date          = models.DateField(blank=True,null=True)
    discharge_date          = models.DateField(blank=True,null=True)
    amount                  = models.FloatField(blank=True,null=True,default=0)

    test_name               = models.CharField(max_length=255,blank=True,null=True)
    test_date               = models.DateField(blank=True,null=True)
    test_price              = models.FloatField(blank=True,null=True,default=0)
    test_result             = models.CharField(max_length=255,blank=True,null=True)
    doctor_remark           = models.TextField(blank=True,null=True)

    class Meta:
        
        verbose_name        = 'Patient'
        verbose_name_plural = 'Patient'

    def __str__(self):
        return f"{self.id} - {self.first_name}- {self.test_name}"