from django.contrib import admin
from django.urls import path,include
from .views import PatientAPI

app_name= 'users'

urlpatterns = [

    path('api/patient/', PatientAPI.as_view({'get':'get','post':'post'}), name='patients'),
    path('api/manage-patient/<int:id>', PatientAPI.as_view({'get':'getSpecificPatient','delete':'delete','put':'put'}), name='patient-by-id'),

    
]